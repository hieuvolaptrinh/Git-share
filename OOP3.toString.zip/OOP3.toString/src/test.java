
public class test {
public static void main(String[] args) {
	MyDate md1= new MyDate(19,10,2005);
	MyDate md2= new MyDate(22,11,2022);
	MyDate md3= new MyDate(9,7,2035);
	
	System.out.println(md1);
	
	
}
}
